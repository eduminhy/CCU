package com.team200.proj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CcuApplicationTests {

	@Test
	void contextLoads() {
	}

}
