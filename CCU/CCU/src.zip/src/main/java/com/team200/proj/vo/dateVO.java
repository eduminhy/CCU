package com.team200.proj.vo;

public class dateVO {
private String sunday;
private String monday;
private String tuesday;
private String wednesday;
private String thursday;
private String friday;
private String saturday;
private String holiday;


@Override
public String toString() {
	return "dateVO [sunday=" + sunday + ", monday=" + monday + ", tuesday=" + tuesday + ", wednesday=" + wednesday
			+ ", thursday=" + thursday + ", friday=" + friday + ", saturday=" + saturday + ", holiday=" + holiday + "]";
}
public String getHoliday() {
	return holiday;
}
public void setHoliday(String holiday) {
	this.holiday = holiday;
}
public String getSunday() {
	return sunday;
}
public void setSunday(String sunday) {
	this.sunday = sunday;
}
public String getMonday() {
	return monday;
}
public void setMonday(String monday) {
	this.monday = monday;
}
public String getTuesday() {
	return tuesday;
}
public void setTuesday(String tuesday) {
	this.tuesday = tuesday;
}
public String getWednesday() {
	return wednesday;
}
public void setWednesday(String wednesday) {
	this.wednesday = wednesday;
}
public String getThursday() {
	return thursday;
}
public void setThursday(String thursday) {
	this.thursday = thursday;
}
public String getFriday() {
	return friday;
}
public void setFriday(String friday) {
	this.friday = friday;
}
public String getSaturday() {
	return saturday;
}
public void setSaturday(String saturday) {
	this.saturday = saturday;
}





//private String creator;
//
//<mt20id>PF132236</mt20id>
//<prfnm>우리연애할까</prfnm>
//<prfpdfrom>2016.05.12</prfpdfrom>
//<prfpdto>2016.07.31</prfpdto>
//<fcltynm>피가로아트홀(구 훈아트홀) (피가로아트홀)</fcltynm>
//<prfcast>김부연, 임정균, 최수영</prfcast>
//<prfcrew>천정민</prfcrew>
//<dtguidance>화요일 ~ 금요일(20:00), 토요일(16:00,19:00), 일요일(15:00,18:00)</dtguidance>
//<prfruntime>1시간 30분</prfruntime>
//<prfage>만 12세 이상</prfage>
//<entrpsnm>극단 피에로</entrpsnm>
//<pcseguidance>전석 30,000원</pcseguidance>
//<poster>http://www.kopis.or.kr/upload/pfmPoster/PF_PF132236_160704_142630.gif</poster>
//<sty> </sty>
//<genrenm>연극</genrenm>
//<prfstate>공연중</prfstate>
//<openrun>Y</openrun>
//<styurls>
//    <styurl>http://www.kopis.or.kr/upload/pfmIntroImage/PF_PF132236_160704_0226303.jpg</styurl>
//    <styurl>http://www.kopis.or.kr/upload/pfmIntroImage/PF_PF132236_160704_0226302.jpg</styurl>
//    <styurl>http://www.kopis.or.kr/upload/pfmIntroImage/PF_PF132236_160704_0226301.jpg</styurl>
//    <styurl>http://www.kopis.or.kr/upload/pfmIntroImage/PF_PF132236_160704_0226300.jpg</styurl>
//</styurls>
//<mt10id>FC001431</mt10id>
//<dtguidance>화요일 ~ 금요일(20:00), 토요일(16:00,19:00), 일요일(15:00,18:00)</dtguidance>
	

		
	
}
