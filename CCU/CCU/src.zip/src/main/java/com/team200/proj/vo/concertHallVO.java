package com.team200.proj.vo;

public class concertHallVO {
	private String id;
private String name;
private String seats_count;
private String open_count;
private String play_count;
private String total_audience;
private String tel;
private String url;
private String addr;
private String lat;
private String lng;
private String concert_hall_count;
//<fcltynm>예술의전당</fcltynm>
//<mt10id>FC000001</mt10id>
//<mt13cnt>9</mt13cnt>
//<fcltychartr>국립</fcltychartr>
//<opende>1988</opende>
//<seatscale>164376</seatscale>
//<telno>02-580-1300</telno>
//<relateurl>http://www.sac.or.kr</relateurl>
//<adres>서울특별시 서초구 남부순환로 2406 (서초동)</adres>
//<la>37.4786896</la>
//<lo>127.01182410000001</lo>
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getSeats_count() {
	return seats_count;
}
public void setSeats_count(String seats_count) {
	this.seats_count = seats_count;
}
public String getOpen_count() {
	return open_count;
}
public void setOpen_count(String open_count) {
	this.open_count = open_count;
}
public String getPlay_count() {
	return play_count;
}
public void setPlay_count(String play_count) {
	this.play_count = play_count;
}
public String getTotal_audience() {
	return total_audience;
}
public void setTotal_audience(String total_audience) {
	this.total_audience = total_audience;
}
public String getTel() {
	return tel;
}
public void setTel(String tel) {
	this.tel = tel;
}
public String getUrl() {
	return url;
}
public void setUrl(String url) {
	this.url = url;
}
public String getAddr() {
	return addr;
}
public void setAddr(String addr) {
	this.addr = addr;
}
public String getLat() {
	return lat;
}
public void setLat(String lat) {
	this.lat = lat;
}
public String getLng() {
	return lng;
}
public void setLng(String lng) {
	this.lng = lng;
}
public String getConcert_hall_count() {
	return concert_hall_count;
}
public void setConcert_hall_count(String concert_hall_count) {
	this.concert_hall_count = concert_hall_count;
}


}
