package com.team200.proj.vo;

public class festivalVO {
private String id;
private String name;
//private int open_year;
//private String character;
private String startdate;
private String enddate;
private String place_name;
private String mainposter;
private String genre;
private String state;
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getStartdate() {
	return startdate;
}
public void setStartdate(String startdate) {
	this.startdate = startdate;
}
public String getEnddate() {
	return enddate;
}
public void setEnddate(String enddate) {
	this.enddate = enddate;
}
public String getPlace_name() {
	return place_name;
}
public void setPlace_name(String place_name) {
	this.place_name = place_name;
}
public String getMainposter() {
	return mainposter;
}
public void setMainposter(String mainposter) {
	this.mainposter = mainposter;
}
public String getGenre() {
	return genre;
}
public void setGenre(String genre) {
	this.genre = genre;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}



//<dbs>
//<db>
//  <mt20id>PF148232</mt20id>
//  <prfnm>제5회 무죽 페스티벌, 두병사 이야기</prfnm>
//  <prfpdfrom>2019.05.14</prfpdfrom>
//  <prfpdto>2019.05.26</prfpdto>
//  <fcltynm>극장 동국</fcltynm>
//  <poster>http://www.kopis.or.kr/upload/pfmPoster/PF_PF148232_190514_115248.gif</poster>
//  <genrenm>연극</genrenm>
//  <prfstate>공연중</prfstate>
//  <festival>Y</festival>
//</db>
//<db>


	
}
