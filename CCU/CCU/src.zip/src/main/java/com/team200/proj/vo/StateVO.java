package com.team200.proj.vo;

public class StateVO {
	
	private String scheduleDate_id;
	private String seatno;
	
	public String getScheduleDate_id() {
		return scheduleDate_id;
	}
	public void setScheduleDate_id(String scheduleDate_id) {
		this.scheduleDate_id = scheduleDate_id;
	}
	public String getSeatno() {
		return seatno;
	}
	public void setSeatno(String seatno) {
		this.seatno = seatno;
	}
	
	
}
