package com.team200.proj.vo;

public class placeVO {
private String id;
private String name;
//private int open_year;
//private String character;
private int seats_count;
private int concert_hall_count;
private String tel;
private String url;
private String addr;
private double lat;
private double lng;
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getSeats_count() {
	return seats_count;
}
public void setSeats_count(int seats_count) {
	this.seats_count = seats_count;
}
public int getConcert_hall_count() {
	return concert_hall_count;
}
public void setConcert_hall_count(int concert_hall_count) {
	this.concert_hall_count = concert_hall_count;
}
public String getTel() {
	return tel;
}
public void setTel(String tel) {
	this.tel = tel;
}
public String getUrl() {
	return url;
}
public void setUrl(String url) {
	this.url = url;
}
public String getAddr() {
	return addr;
}
public void setAddr(String addr) {
	this.addr = addr;
}
public double getLat() {
	return lat;
}
public void setLat(double lat) {
	this.lat = lat;
}
public double getLng() {
	return lng;
}
public void setLng(double lng) {
	this.lng = lng;
}









//<fcltynm>예술의전당</fcltynm>
//<mt10id>FC000001</mt10id>
//<mt13cnt>9</mt13cnt>
//<fcltychartr>국립</fcltychartr>
//<opende>1988</opende>
//<seatscale>164376</seatscale>
//<telno>02-580-1300</telno>
//<relateurl>http://www.sac.or.kr</relateurl>
//<adres>서울특별시 서초구 남부순환로 2406 (서초동)</adres>
//<la>37.4786896</la>
//<lo>127.01182410000001</lo>


	
}
