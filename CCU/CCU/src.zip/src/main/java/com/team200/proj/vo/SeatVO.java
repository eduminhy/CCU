package com.team200.proj.vo;

public class SeatVO {
	private String seat_num;
	private String order_list_no;
	private String seatcnt;
	private String scheduleDate_id;
	
	public String getSeat_num() {
		return seat_num;
	}
	public void setSeat_num(String seat_num) {
		this.seat_num = seat_num;
	}
	public String getOrder_list_no() {
		return order_list_no;
	}
	public void setOrder_list_no(String order_list_no) {
		this.order_list_no = order_list_no;
	}
	public String getSeatcnt() {
		return seatcnt;
	}
	public void setSeatcnt(String seatcnt) {
		this.seatcnt = seatcnt;
	}
	public String getScheduleDate_id() {
		return scheduleDate_id;
	}
	public void setScheduleDate_id(String scheduleDate_id) {
		this.scheduleDate_id = scheduleDate_id;
	}
	
	
}
