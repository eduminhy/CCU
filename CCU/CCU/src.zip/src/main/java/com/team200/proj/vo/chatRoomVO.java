package com.team200.proj.vo;

public class chatRoomVO {
	
	private int chat_id;
	private int chat_room_id;
	private String chat_info;
	private String chat_datetime;
	private int chat_role;
	
	public int getChat_id() {
		return chat_id;
	}
	public void setChat_id(int chat_id) {
		this.chat_id = chat_id;
	}
	public int getChat_room_id() {
		return chat_room_id;
	}
	public void setChat_room_id(int chat_room_id) {
		this.chat_room_id = chat_room_id;
	}
	public String getChat_info() {
		return chat_info;
	}
	public void setChat_info(String chat_info) {
		this.chat_info = chat_info;
	}
	public String getChat_datetime() {
		return chat_datetime;
	}
	public void setChat_datetime(String chat_datetime) {
		this.chat_datetime = chat_datetime;
	}
	public int getChat_role() {
		return chat_role;
	}
	public void setChat_role(int chat_role) {
		this.chat_role = chat_role;
	}
}
